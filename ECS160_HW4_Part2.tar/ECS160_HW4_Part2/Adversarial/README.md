### Kyle Catapusan
### Sarah Quick

### Adversarial Crashing Input Files
- <263> <Program received signal SIGSEGV, Segmentation fault. Stack Smashing Error Created by Buffer Overflow.> <id_000000,sig:11,src:000075,op:havoc,rep:8>
- <263> <Program received signal SIGSEGV, Segmentation fault. Stack Smashing Error Created by Buffer Overflow.> <id_000001,sig:11,src:000080,op:havoc,rep:16>
- <263> <Program received signal SIGSEGV, Segmentation fault. Stack Smashing Error Created by Buffer Overflow.> <id:000002,sig:11,src:000080,op:havoc,rep:32>
- <263> <Program received signal SIGSEGV, Segmentation fault. Error caused by stack or buffer overflow.> <id:000003,sig:11,src:000080,op:havoc,rep:128>
- <263> <Program received signal SIGSEGV, Segmentation fault. printOutput() can't handle names longer than 50 chars, so crashes due to invalid access> <id:000004,sig:11,src:000080,op:havoc,rep:16>
- <263> <Program received signal SIGSEGV, Segmentation fault. Stack Smashing Error Created by Buffer Overflow.> <id_000005,sig:11,src:000080,op:havoc,rep:128>
- <263> <Program received signal SIGSEGV, Segmentation fault. Stack Smashing Error Created by Buffer Overflow.> <id_000006,sig:11,src:000049,op:havoc,rep:64>
- <68> <Program received signal SIGSEGV, Segmentation fault. Program can't handle non-existent files.> <nonexistent file>
- <Probably 131> <Program Segfaults when ran normally within Docker container, but executes in gdb. Probably becuase program does not handle files larger 20000 lines and the longFile.csv has more than that.> <longFile>
