### Kyle Catapusan
### Sarah Quick

### Warm-up Crashing Input Files
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000000,sig:11,src:000000,op:flip1,pos:47>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000001,sig:11,src:000000,op:flip1,pos:76>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000002,sig:11,src:000000,op:flip1,pos:112>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000003,sig:11,src:000000,op:flip1,pos:185>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000004,sig:11,src:000000,op:flip1,pos:375>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000005,sig:11,src:000000,op:arith8,pos:4,val:-24>
- <72> <Program received signal SIGSEGV, Segmentation fault.> <id:000006,sig:11,src:000000,op:arith8,pos:38,val:-24>
- <72> <Program received signal SIGSEGV, Segmentation fault.bt> <id:000007,sig:11,src:000000,op:arith8,pos:44,val:-34>
- <72> <Program received signal SIGSEGV, Segmentation fault.bt> <id:000008,sig:11,src:000000,op:havoc,rep:64>
- <72> <Program received signal SIGSEGV, Segmentation fault.bt> <id:000009,sig:11,src:000000,op:havoc,rep:128>
